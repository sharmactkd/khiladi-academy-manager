import api from "./api.js";

const multipartConfig = {
  headers: {
    "Content-Type": "multipart/form-data",
  },
};

export const studentApi = {
  getAll: async (params = {}) => {
    const res = await api.get("/students", { params });
    return res.data;
  },

  getById: async (id) => {
    const res = await api.get(`/students/${id}`);
    return res.data;
  },

  create: async (payload) => {
    const res =
      payload instanceof FormData
        ? await api.post("/students", payload, multipartConfig)
        : await api.post("/students", payload);

    return res.data;
  },

  update: async (id, payload) => {
    const res =
      payload instanceof FormData
        ? await api.patch(`/students/${id}`, payload, multipartConfig)
        : await api.patch(`/students/${id}`, payload);

    return res.data;
  },

  updateStatus: async (id, status) => {
    const res = await api.patch(`/students/${id}/status`, { status });
    return res.data;
  },

  importBulk: async (payload = {}) => {
    const students = Array.isArray(payload) ? payload : payload.students || [];
    const destination = Array.isArray(payload) ? {} : payload.destination || {};
    const duplicateMode = Array.isArray(payload) ? "skip" : payload.duplicateMode || "skip";

    const res = await api.post("/students/import", {
      students,
      destination,
      duplicateMode,
      allowProvisional: !Array.isArray(payload) && payload.allowProvisional === true,
    });

    return res.data;
  },

  remove: async (id) => {
    const res = await api.delete(`/students/${id}`);
    return res.data;
  },
};

export const getStudents = studentApi.getAll;
export const getStudentById = studentApi.getById;
export const createStudent = studentApi.create;
export const updateStudent = studentApi.update;
export const importStudents = studentApi.importBulk;
export const deleteStudent = studentApi.remove;

export default studentApi;
